// script.js
function navigateTo(page) {
    alert("Navigating to " + page);
    // Uncomment the following line to enable actual navigation
    // window.location.href = page + ".html"; 
}